# Example asset used for tests
